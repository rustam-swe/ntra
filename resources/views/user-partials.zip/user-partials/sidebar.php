<nav id="sidebar" class="sidebar-wrapper sidebar-dark">
    <div class="sidebar-content">
        <div class="sidebar-brand">
            <a href="/user"><img src="/dashboard/assets/images/logo-light.png" alt=""></a>
        </div>

        <ul class="sidebar-menu border-t border-white/10" data-simplebar style="height: calc(100% - 70px);">
            <li>
                <a href="/user"><i class="mdi mdi-chart-bell-curve-cumulative me-2"></i>Dashboard</a>
            </li>

            <li class="sidebar-dropdown">
                <a href="javascript:void(0)"><i class="mdi mdi-account-edit me-2"></i> E'lonlar</a>
                <div class="sidebar-submenu">
                    <ul>
                        <li><a href="/user/ads/create"><i class="mdi mdi-home-plus me-2"></i>E'lon qo'shish</a></li>
                        <li><a href="/user/ads"><i class="mdi mdi-home-city me-2"></i>E'lonlar</a></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
</nav>